from django.contrib import admin

# Register your models here.
from lms_app.models import Professor
admin.site.register(Professor)
